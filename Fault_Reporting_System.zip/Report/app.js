const { render } = require('ejs')
var express = require('express')
const app = express()
const { model } = require('mongoose')
app.set('view engine', 'ejs')
app.use(express.urlencoded({ extended: true }))
const con = require("./database")
const r = require("./models/register")
const repo = require("./models/report")
const emp = require("./models/employee")

var m = "";
var sid = "";
var repoid = "";
var empem = "";

app.get("/", (req, res) => {
    res.render("login.ejs", { msg: "", errmsg: "" })
})


app.post("/login", (req, res) => {
    r.find({ email: req.body.email, pass: req.body.pass }, (err, doc) => {
        if (err) {
            console.log("Errorr..!!")
        }
        else if (doc.length > 0) {
            r.find({ email: req.body.email, role: 1 }, (err, doc1) => {
                if (err) {
                    console.log("Normal User Error")
                }
                else if (doc1.length > 0) {
                    console.log("Logged in..")
                    var data = repo.find({repaired:false}, (err, doc) => {
                        if (err) {
                            console.log("Fetching Table Error")
                        }
                        else {
                            m = req.body.email;
                            res.render("hom.ejs", { data: doc, msg: "" })
                        }
                    })
                }
                else {
                    var data1 = repo.find({}, (err, doc2) => {
                        if (err) {
                            console.log("Fetching Table Error")
                        }
                        else {
                            res.render("admin.ejs", { data1: doc2 })
                        }
                    })
                }
            })

        }
        else {
            res.render("login.ejs", { errmsg: "Invalid Credentials",msg:"" })
        }
    })
})




app.get("/login", (req, res) => {
    res.render("login.ejs", { errmsg1: "", errmsg: "" })
})

app.post("/registration", (req, res) => {
    r.find({ email: req.body.email }, (err, doc) => {
        if (err) {
            console.log("Syntax Errorr..")
        }
        else if (doc.length > 0) {
            console.log("Already Present")
            var msg1 = "Email Already Present..!!"
            res.render("index.ejs", { msg: msg1 })
        }
        else {
            r.insertMany({
                name: req.body.name,
                roll: req.body.roll,
                cour: req.body.cour,
                dept: req.body.dept,
                pass: req.body.pass,
                email: req.body.email,
                role: 1,

            }, (err, doc) => {
                if (err) {
                    console.log("Errorrrr....!!!")
                }
                else {
                    console.log("Inserted SuccessFully")
                    res.render("login.ejs", { msg: "", errmsg: "" })
                }
            })
        }
    })
})


app.post("/empreg", (req, res) => {
    emp.find({ email: req.body.email }, (err, doc) => {
        if (err) {
            console.log("Syntax Errorr..")
        }
        else if (doc.length > 0) {
            console.log("Already Present")
            var msg1 = "Email Already Present..!!"
            var data1 = emp.find({}, (err, doc2) => {
                if (err) {
                    console.log("Fetching Table Error")
                }
                else {
                    console.log(doc2)
                    res.render("employee.ejs", { data1: doc2 })
                }
            })
        }
        else {
            emp.insertMany({
                name: req.body.name,
                empid: req.body.empid,
                pass: req.body.pass,
                email: req.body.email,
                role: 2,

            }, (err, doc) => {
                if (err) {
                    console.log("Errorrrr....!!!")
                }
                else {
                    console.log("Inserted SuccessFully")
                    var data1 = emp.find({}, (err, doc2) => {
                        if (err) {
                            console.log("Fetching Table Error")
                        }
                        else {
                            res.render("employee.ejs", { data1: doc2 })
                        }
                    })
                }
            })
        }
    })
})


app.post("/report", (req, res) => {
    repo.find({
        Room: req.body.roomno, ApplianceName: req.body.appname,
        ApplianceNo: req.body.appno, repaired: false
    }, (err, doc) => {
        if (err) {
            console.log("Syntax Errorr..")
        }
        else if (doc.length > 0) {
            console.log("Already Reported")
            var msg1 = "Error Already Reported..!!"
            var data = repo.find({repaired : false}, (err, doc) => {
                if (err) {
                    console.log("Fetching Table Error")
                }
                else {
                    res.render("hom.ejs", { data: doc, msg: msg1 })
                }
            })
        }
        else {
            repo.insertMany({
                Room: req.body.roomno,
                ApplianceName: req.body.appname,
                ApplianceNo: req.body.appno,
                email: m,
                repaired: false,

            }, (err, doc) => {
                if (err) {
                    console.log("report Errorrrr....!!!")
                }
                else {
                    var data = repo.find({repaired:false}, (err, doc) => {
                        if (err) {
                            console.log("Fetching Table Error")
                        }
                        else {
                            res.render("hom.ejs", { data: doc, msg: "" })
                        }
                    })
                }
            })
        }
    })

})

app.get("/update", (req, res) => {
    res.render("update.ejs")
})

app.get("/home", (req, res) => {
    var data = repo.find({ repaired:false }, (err, doc) => {
        if (err) {
            console.log("Fetching Table Error")
        }
        else {
            res.render("hom.ejs", { data: doc, msg: "" })
        }
    })
})

app.post("/del/:id", (req, res) => {
    repo.findOneAndDelete({ _id: req.params.id }, (err, doc) => {
        if (err) {
            console.log("Deleting Error..!!")
        }
        else {
            var data1 = repo.find({}, (err, doc2) => {
                if (err) {
                    console.log("Fetching Table Error")
                }
                else {
                    res.render("admin.ejs", { data1: doc2 })
                }
            })
        }
    })
})


app.post("/delemp/:id", (req, res) => {
    emp.findOneAndDelete({ _id: req.params.id }, (err, doc) => {
        if (err) {
            console.log("Deleting Error..!!")
        }
        else {
            var data1 = emp.find({}, (err, doc2) => {
                if (err) {
                    console.log("Fetching Table Error")
                }
                else {
                    res.render("employee.ejs", { data1: doc2 })
                }
            })
        }
    })
})



app.post("/assign/:id",(req, res) =>{
    repoid = req.params.id
    
    var data = emp.find({}, (err,doc) =>{
        if(err){
            console.log("Fetching Error")
        }
        else{
            
            res.render("assignemp.ejs",{data1 : doc})
        }
    })
})




app.post("/updatestud/:id",(req,res)=>{
    sid = req.params.id
    r.findOne({_id:req.params.id },(err,doc)=>{
        if(err){
            console.log("UPDATE TABLE NOT FETECHED")
        }
        else{
            var data=r.findOne({_id:req.params.id }, (err,doc1) =>{
                if(err){
                    console.log("Errorrr!!!!")
                }
                else{
                    
                    res.render("updstud.ejs",{data :doc1});
                }
            })
        }
    })
})

app.post("/ud",(req,res)=>{
    var name = req.body.na
    var roll = req.body.r
    var dep = req.body.dept
    var c = req.body.branch
    r.findOneAndUpdate({_id:sid},{$set:{"name" :name,"roll" :roll,"dept": dep,"cour" :c}} , (err,doc)=>{
        if(err){
            console.log("error while Updatinggg")
        }
        else{
            var data1 = r.find({}, (err, doc2) => {
                if (err) {
                    console.log("Fetching Table Error")
                }
                else {
                    res.render("studdet.ejs", { data1: doc2 })
                }
            })
        }
    })
})


app.get("/rp", (req,res)=>{
    var data1 = repo.find({}, (err, doc2) => {
        if (err) {
            console.log("Fetching Table Error")
        }
        else {
            res.render("admin.ejs", { data1: doc2 })
        }
    })
})


app.post("/up", (req, res) => {
    var pass = req.body.pass
    var np = req.body.newpass
    var em = req.body.email
    
    r.updateOne({ "email": em }, { $set: { "pass": np } }, (err, doc1) => {
        if (err) {
            console.log("Password Update Error")
        }
        else {
            var data = repo.find({ email: m }, (err, doc) => {
                if (err) {
                    console.log("Error in fetching for email")
                }
                else {
                    var da = r.find({ email: m }, (err, doc1) => {
                        if (err) {
                            console.log("Error in fetching for email")
                        }
                        else {
                            res.render("details.ejs", { data: doc, da: doc1 })
                        }
                    })
                }
            })
        }
    })
    
    
})



app.post("/empup", (req, res) => {
    var pass = req.body.pass
    var np = req.body.newpass
    var em = req.body.email
    
    emp.updateOne({ "email": em }, { $set: { "pass": np } }, (err, doc1) => {
        if (err) {
            console.log("Password Update Error")
        }
        else {
            
                    var da = emp.find({ email: empem }, (err, doc1) => {
                        if (err) {
                            console.log("Error in fetching for email")
                        }
                        else {
                            res.render("empdet.ejs", { da: doc1 })
                        }
                    })
                
        }
    })
    
    
})




app.get("/studentdetails", (req, res) => {
    
    var data1 = r.find({}, (err, doc2) => {
        if (err) {
            console.log("Fetching Table Error")
        }
        else {
            res.render("studdet.ejs", { data1: doc2 })
        }
    })
})


app.post("/assignemp/:id" , (req,res) =>{
    var empid = req.params.id
    repo.updateOne({ _id : repoid},{$set :{"empid" : empid} }, (err,doc) => {
        if(err){
            console.log(empid)
            console.log(repoid)
            console.log("Error in Assigning")
        }
        else{
            console.log("Successfully Assigned..!!")
            var data = emp.find({}, (err,doc) =>{
                if(err){
                    console.log("Fetching Error")
                }
                else{
                    
                    res.render("assignemp.ejs",{data1 : doc})
                }
            })
            
        }
    })
})

app.get("/emp1" , (req,res) => {
    emp.find({},(err,doc) => {
        res.render("employee.ejs",{data1 : doc})
    })
})


app.post("/employee",(req,res)=>{
    empem = req.body.email
    emppa = req.body.pass
    emp.find({email : req.body.email },{_id : 1}, (err,doc)=>{
        if(err){
            console.log("Employee Errorrr")
        }
        else if(doc.length > 0){
            var data = repo.find({ empid : doc[0]._id.toString() },(err,doc2) => {
                if(err){
                    console.log("Reports Fetching Error")
                }
                else{
                    
                    res.render("empreports.ejs",{data1 :doc2})
                }
            })
        }
        else{
            res.render("login.ejs", { errmsg:"",msg:"Invalid Credentials" })
            
        }
    })
})


app.get("/deta", (req,res) => {
    emp.find({email : empem}, (err,doc) =>{
        if(err){
            console.log("Errorr in fetching details")
        }
        else{
            res.render("empdet.ejs",{da : doc})
        }
    })
})



app.post("/check/:id" ,async(req,res) =>{
    var data = await repo.updateOne({ _id : req.params.id },{$set : { "repaired" : true }});
    repo.findById({ _id : req.params.id },(err,doc) =>{
        if(err){
            console.log(err)
        }
        else{
            var data = repo.find({ empid : doc.empid },(err,doc2) => {
                if(err){
                    console.log("Reports Fetching Error")
                }
                else{
                    console.log(doc2)
                    res.render("empreports.ejs",{data1 :doc2})
                }
            })
        }
    })
})


app.get("/signup", (req, res) => {
    res.render("index.ejs", { msg: "" })
})

app.get("/details", (req, res) => {
    var data = repo.find({ email: m }, (err, doc) => {
        if (err) {
            console.log("Error in fetching for email")
        }
        else {
            var da = r.find({ email: m }, (err, doc1) => {
                if (err) {
                    console.log("Error in fetching for email")
                }
                else {
                    res.render("details.ejs", { data: doc, da: doc1 })
                }
            })
        }
    })
})

app.get("/log", (req, res) => {
    res.render("login.ejs", { msg: "", errmsg: "" })
})


app.listen(2002, () => {
    console.log("server is listening....")
})