var mongoose = require('mongoose');

const rep = new mongoose.Schema({
    
    Room:{
        type:Number,
        required:true,
    },
    ApplianceName:{
        type:String,
        required:true,
    },
    ApplianceNo:{
        type:Number,
        required:true,
    },
    email:{
        type:String,
        required:true,
    },
    empid :{
        type:String,
        required:false
    },
    repaired : {
        type : Boolean,
        required : false
    }
})
module.exports=User= mongoose.model("reports",rep)