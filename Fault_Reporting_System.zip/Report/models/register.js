var mongoose = require('mongoose');

const reg = new mongoose.Schema({
    
    name:{
        type:String,
        required:true,
    },
    roll:{
        type:Number,
        required:true,
    },
    cour:{
        type:String,
        required:true,
    },
    dept:{
        type:String,
        required:true,
    },
    email:{
        type:String,
        required:true,
    },
    pass:{
        type:String,
        required:true,
    },
    role:{
        type:Number,
        required:true,
    }
    
})
module.exports=User= mongoose.model("registers",reg)