var mongoose = require('mongoose');

const reg = new mongoose.Schema({
    
    name:{
        type:String,
        required:true,
    },
    empid:{
        type:Number,
        required:true,
    },
    email:{
        type:String,
        required:true,
    },
    pass:{
        type:String,
        required:true,
    },
    role:{
        type:Number,
        required:true,
    },
    
    
})
module.exports=User= mongoose.model("employee",reg)