// const { default: mongoose } = require("mongoose");

const mongoose =  require('mongoose');
const con = mongoose.connect("mongodb://127.0.0.1:27017/DBproj",{
    useNewUrlParser:true,useUnifiedTopology:true},(err)=>{
        if(err){
            console.log(err);
        }
        else{
            console.log("Database Connected Successfully...!!!")
        }
    }
);
module.exports = con;
